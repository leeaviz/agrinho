// JavaScript
document.getElementById('btnMensagem').addEventListener('click', function() {
    alert('Juntos, podemos construir um futuro mais verde e justo para todos!');
});
